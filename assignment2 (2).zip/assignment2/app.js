const express=require('express');
const PORT =9999;
const app =express();
const fs = require('fs');
app.set('view engine','pug');
app.set('views','./views');
app.use(express.json());
app.use(express.urlencoded({extended:false}));
app.use("/static",express.static("public"));


//define routes
app.get("/",(req,res)=>{
    res.render("first_view");
})

app.get("/contacts",(req,res)=>{
    res.render("contacts");
})

app.get("/about",(req,res)=>{
    res.render("about");
})

app.get("/services",(req,res)=>{
    res.render("services");
})

app.get("/gallery",(req,res)=>{
    res.render("gallery");
})

app.post("/contacts",(req,res)=>{
    let name = req.body.name;
    let email = req.body.email;
    let mobile = req.body.mobile;
    let city = req.body.city;
    let remark = req.body.remark;
    let data=(' name: ' + name + '\n email : ' + email + '\n mobile : ' + mobile + '\n city : '+ city + '\n remark : '+ remark);

    if(!fs.existsSync(`./contacts/${email}`)){
        fs.mkdirSync(`./contacts/${email}`);
        fs.writeFileSync(`./contacts/${email}/details.txt`,`${data.toString()}`);
        res.send("thanks for contacting us..");
    }
    else{
        res.send("email already exists");
    }
})

app.listen(PORT,(err)=>{
    if(err) throw err;
    else console.log(`server work on ${PORT}`)
})